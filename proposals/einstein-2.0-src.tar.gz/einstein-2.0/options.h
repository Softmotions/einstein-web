#ifndef __OPTIONS_H__
#define __OPTIONS_H__


#include "widgets.h"



void showOptionsWindow(Area *area);


#endif

